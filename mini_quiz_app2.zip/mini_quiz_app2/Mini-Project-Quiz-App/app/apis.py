from flask_apispec import marshal_with, doc, use_kwargs
from flask_apispec.views import MethodResource
from flask_restful import Resource

from app import *
from app.models import *
from app.schemas import *
from app.services import *

"""
[Sign Up API] : Its responsibility is to perform the signup activity for the user.
"""


#  Restful way of creating APIs through Flask Restful
class SignUpAPI(MethodResource, Resource):
    @doc(description='Sign Up API', tags=['SignUp'])
    @use_kwargs(SignupRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            create_user(**kwargs)
            return APIResponse().dump(dict(message="User is Successfully Registered")), 200
        except Exception as Error:
            print(str(Error))
            return APIResponse().dump(dict(message=f'Error registering user : {str(Error)}')), 400


api.add_resource(SignUpAPI, '/signup')
docs.register(SignUpAPI)

"""
[Login API] : Its responsibility is to perform the login activity for the user and 
create session id which will be used for all subsequent operations.
"""


class LoginAPI(MethodResource, Resource):
    @doc(description='Login API', tags=['Login'])
    @use_kwargs(LoginRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            is_logged_in, session_id = login_user(**kwargs)
            if is_logged_in:
                return APIResponse().dump(dict(message='User login is Successful')), 200
            else:
                return APIResponse().dump(dict(message='Unable login user')), 404
        except Exception as Error:
            print(str(Error))
            return APIResponse().dump(dict(message=f'Error Logging in user : {str(Error)}')), 400


api.add_resource(LoginAPI, '/login')
docs.register(LoginAPI)

"""
[Logout API] : Its responsibility is to perform the logout activity for the user.
"""


class LogoutAPI(MethodResource, Resource):
    @doc(description='Logout API', tags=['Logout'])
    @use_kwargs(LogoutRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            is_logged_out = logout_user(kwargs['session_id'])

            if is_logged_out:
                return APIResponse().dump(dict(message='User Logged out Successfully')), 200
            else:
                return APIResponse().dump(dict(message='User not logged in')), 401
        except Exception as Error:
            return APIResponse().dump(dict(message=f'Unable to Logout user : {str(Error)} '))


api.add_resource(LogoutAPI, '/logout')
docs.register(LogoutAPI)

"""
[Add Question API] : Its responsibility is to add question to the question bank.
Admin has only the rights to perform this activity.
"""


class AddQuestionAPI(MethodResource, Resource):
    @doc(description='Add Question API', tags=['Questions'])
    @use_kwargs(AddQuestionRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User not logged in')), 404
            is_admin = check_if_admin(user_id)

            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin')), 401

            add_question(**kwargs)

            return APIResponse().dump(dict(message='Question Added Successfully.')), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error adding Question to the quiz :{str(Error)}')), 400


api.add_resource(AddQuestionAPI, '/add.question')
docs.register(AddQuestionAPI)

"""
[List Questions API] : Its responsibility is to list all questions present actively in the question bank.
Here only Admin can access all the questions.
"""


class ListQuestionAPI(MethodResource, Resource):
    @doc(description='List Questions API', tags=['List Questions'])
    @marshal_with(ListQuestionsResponse)
    def get(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 401

            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin')), 401

            question_list = list_all_questions()

            return ListQuestionsResponse().dump(dict(questions=question_list)), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error printing Questions :{str(Error)} '))


api.add_resource(ListQuestionAPI, '/list.questions')
docs.register(ListQuestionAPI)

"""
[Create Quiz API] : Its responsibility is to create quiz and only admin can create quiz using this API.
"""


class CreateQuizAPI(MethodResource, Resource):
    @doc(description='Create Quiz API', tags=['Quiz'])
    @use_kwargs(CreateQuizRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])

            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 401

            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin')), 401

            create_quiz(**kwargs)

            return APIResponse().dump(dict(message='Quiz Created Successfully')), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error Occurred While creating the quiz :{str(Error)} '))


api.add_resource(CreateQuizAPI, '/create.quiz')
docs.register(CreateQuizAPI)

"""
[Assign Quiz API] : Its responsibility is to assign quiz to the user. Only Admin can perform this API call.
"""


class AssignQuizAPI(MethodResource, Resource):
    @doc(description='Assign Quiz API', tags=['Assign Quiz'])
    @use_kwargs(AssignQuizRequest, location=('json'))
    @marshal_with(APIResponse)
    def post(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])

            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 401

            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin')), 401

            assign_quiz(**kwargs)

            return APIResponse().dump(dict(message='Assigning quiz to user is Successful'))

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error Assigning quiz to the User:{str(Error)}'))


api.add_resource(AssignQuizAPI, '/assign.quiz')
docs.register(AssignQuizAPI)

"""
[View Quiz API] : Its responsibility is to view the quiz details.
Only Admin and the assigned users to this quiz can access the quiz details.
"""


class ViewQuizAPI(MethodResource, Resource):
    @doc(description='View Quiz API', tags=['View Quiz'])
    @use_kwargs(ViewQuizRequest, location=('json'))
    @marshal_with(ViewQuizResponse)
    def post(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])

            if not is_active:
                return APIResponse().dump(dict(message='User not logged in')), 401

            has_access = check_quiz_access(**kwargs)
            if not has_access:
                return APIResponse().dump(dict(message='User has no Access to view quiz')), 401

            viewquiz = view_quiz(**kwargs)
            return ViewQuizResponse().dump(dict(viewquiz=viewquiz)), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Can\'t access the quiz :{str(Error)}')), 400


api.add_resource(ViewQuizAPI, '/view.quiz')
docs.register(ViewQuizAPI)

"""
[View Assigned Quiz API] : Its responsibility is to list all the assigned quizzes 
                            with there submittion status and achieved scores.
"""


class ViewAssignedQuizAPI(MethodResource, Resource):
    @doc(description='View Assigned Quiz API', tags=['View Assigned Quiz'])
    @use_kwargs(AssignQuizRequest, location=('json'))
    @marshal_with(ViewAssignedQuizResponse)
    def get(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])
            if not is_active:
                return APIResponse().dump(dict(message='User Not Logged in')), 404
            if len(view_assigned_quiz()) == 0:
                return APIResponse().dump(dict(message='No quiz Assigned to the given user')), 404

            quiz_info = view_assigned_quiz(**kwargs)
            return ViewAssignedQuizResponse().dump(dict(quiz_info=quiz_info)), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error viewing assigned quizzes to the user :{str(Error)}'), 400)


api.add_resource(ViewAssignedQuizAPI, '/assigned.quizzes')
docs.register(ViewAssignedQuizAPI)

"""
[View All Quiz API] : Its responsibility is to list all the created quizzes. Admin can only list all quizzes.
"""


class ViewAllQuizAPI(MethodResource, Resource):
    @doc(description='View All quiz API', tags=['Quiz'])
    @use_kwargs(ViewAllQuizRequest, location=('json'))
    @marshal_with(ViewAllQuizResponse)
    def get(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])

            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 401

            is_admin = check_if_admin(user_id)
            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin')), 401

            if len(view_assigned_quiz()) == 0:
                return APIResponse().dump(dict(message='Quiz not yet created')), 400

            quiz_info = view_all_quiz()
            return ViewAllQuizResponse().dump(dict(quiz_info=quiz_info)), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error Viewing all the quizzes :{str(Error)}')), 400


api.add_resource(ViewAllQuizAPI, '/all.quizzes')
docs.register(ViewAllQuizAPI)

"""
[Attempt Quiz API] : Its responsibility is to perform quiz attempt activity by 
                        the user and the score will be shown as a result of the submitted attempt.
"""


class AttemptQuizAPI(MethodResource, Resource):
    @doc(description='Attempt Quiz API', tags=['Quiz'])
    @use_kwargs(AttemptQuizRequest, location=('json'))
    @marshal_with(AttemptQuizResponse)
    def post(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])

            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 401

            has_access = check_quiz_access(kwargs['quiz_id'], user_id)
            if not has_access:
                return APIResponse().dump(dict(message='User has no Access to view quiz')), 401

            score_achieved = attempt_quiz(user_id, kwargs['quiz_id'], kwargs['responses'])

            return AttemptQuizResponse().dump(dict(score_achieved=score_achieved)), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error Attempting the quiz'))


api.add_resource(AttemptQuizAPI, '/attempt.quiz')
docs.register(AttemptQuizAPI)

"""
[Quiz Results API] : Its responsibility is to provide the quiz results in which the users 
                        having the scores sorted in descending order are displayed, 
                        also the ones who have not attempted are also shown.
                        Admin has only acess to this functionality.
"""


class QuizResultAPI(MethodResource, Resource):
    @doc(description='Quiz Result API', tags=['Quiz'])
    @use_kwargs(QuizResultRequest, location=('json'))
    @marshal_with(QuizResultResponse)
    def post(self, **kwargs):
        try:
            is_active, user_id = check_if_session_is_active(kwargs['session_id'])

            if not is_active:
                return APIResponse().dump(dict(message='User is not logged in')), 401

            is_admin = check_if_admin(user_id)

            if not is_admin:
                return APIResponse().dump(dict(message='User is not admin')), 401

            result = quiz_results(kwargs['quiz_id'])

            if len(result) == 0:
                return APIResponse().dump(message='Results not available for the Quiz')

            return QuizResultResponse().dump(dict(result=result)), 200

        except Exception as Error:
            return APIResponse().dump(dict(message=f'Error prointing result for the Quiz:{str(Error)}'))


api.add_resource(QuizResultAPI, '/quiz.results')
docs.register(QuizResultAPI)
