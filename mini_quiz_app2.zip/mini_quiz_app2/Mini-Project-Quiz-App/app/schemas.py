from marshmallow import Schema, fields, base

"""
This module aims at providing the request and response format for the various api calls.
This also helpful for creating swagger docs for apis testing.
"""


class APIResponse(Schema):
    message = fields.Str(defaul='Success')


class SignupRequest(Schema):
    username = fields.Str(default='username')
    password = fields.Str(default='password')
    name = fields.Str(default='name')
    is_admin = fields.Str(default=0)


class LoginRequest(Schema):
    username = fields.Str(default='username')
    password = fields.Str(default='password')


class LogoutRequest(Schema):
    session_id = fields.Str(default='session_id')


class QuestionRequest(Schema):
    session_id = fields.Str(default='session_id')


class ListQuestionsResponse(Schema):
    question = fields.List(fields.Dict())


class AddQuestionRequest(Schema):
    session_id = fields.Str(default='session_id')
    question = fields.Str(default='question')
    choice1 = fields.Str(default='choice1')
    choice2 = fields.Str(default='choice2')
    choice3 = fields.Str(default='choice3')
    choice4 = fields.Str(default='choice4')
    answer = fields.Str(default='answer')
    marks = fields.Str(default='marks')
    remarks = fields.Str(default='remarks')


class CreateQuizRequest(Schema):
    session_id = fields.Str(default='session_id')
    quiz_name = fields.Str(default='quiz_name')
    quiz_id = fields.Str(default='quiz_id')
    question = fields.Str(default='question')


class AssignQuizRequest(Schema):
    quiz_id = fields.Str(default='quiz_id')
    user_id = fields.Str(default='user_id')
    session_id = fields.Str(default='session_id')
    is_submitted = fields.Str(default=0)


class ViewQuizRequest(Schema):
    quiz = fields.Str(default='quiz_id')


class ViewQuizResponse(Schema):
    quiz = fields.List(fields.Dict())


class ViewAssignedQuizResponse(Schema):
    quiz_info = fields.List(fields.Dict())


class ViewAllQuizRequest(Schema):
    quiz_name = fields.Str(default='quiz_name')
    quiz_id = fields.Str(default='quiz_id')


class ViewAllQuizResponse(Schema):
    quiz = fields.List(fields.Dict())


class AttemptQuizRequest(Schema):
    session_id = fields.Str(default='session_id')
    quiz_id = fields.Str(default='quiz_id')
    user_id = fields.Str(default='user_id')
    question_id = fields.Str(default='question_id')
    response = fields.Str(default='response')


class AttemptQuizResponse(Schema):
    session_id = fields.Str(default='session_id')
    quiz = fields.List(fields.Dict())
    score = fields.Float(default=0.0)
    questions = fields.List(fields.Dict())
    is_completed = fields.Boolean(default=False)
    completion_time = fields.DateTime()


class QuizResultRequest(Schema):
    session_id = fields.Str(default='session_id')
    quiz_id = fields.Str(default='quiz_id')
    score_achieved = fields.Str(default='score_achieved')


class QuizResultResponse(Schema):
    quiz = fields.List(fields.Dict())
    result = fields.List(fields.Dict())
