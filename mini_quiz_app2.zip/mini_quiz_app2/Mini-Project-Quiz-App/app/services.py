from sqlalchemy.orm.session import sessionmaker
from app.models import QuestionMaster, QuizInstance, QuizMaster, QuizQuestions, UserMaster, UserResponses, UserSession
from app import db
import uuid
from flask import session
import datetime
from typing import List
from app.schemas import *

"""
[Services Module] Implement various helper functions here as a part of api
                    implementation using MVC Template
"""


def create_user(**kwargs):
    try:
        user = UserMaster(
            uuid.uuid4(),
            kwargs['name'],
            kwargs['username'],
            kwargs['password'],
            kwargs['is_admin']
        )
        db.session.add(user)
        db.session.commit()
    except Exception as Error:
        raise Error


def check_user_session_is_active(user_id):
    try:
        user_session = UserSession.query.filter_by(user_id=user_id, is_active=1).first()
        if user_session:
            return True, user_session.session_id
        else:
            return False, None

    except Exception as Error:
        raise Error


def login_user(**kwargs):
    try:
        user = UserMaster.query.filter_by(username=kwargs['username'], password=kwargs['password']).first()
        if user:
            print('logged in')

            is_active, session_id = check_user_session_is_active(user.id)

            if not is_active:
                session_id = uuid.uuid4()
                user_session = UserSession(uuid.uuid4(), user.id, session_id)
                db.session.add(user_session)
                db.session.commit()

            else:
                session['session_id'] = session_id
            session['session_id'] = session_id
            return True, session_id

        else:
            return False, None

    except Exception as Error:
        raise Error


def logout_user(session_id):
    try:
        if session['session_id']:
            user_session = UserSession.query.filter_by(session_id=session['session_id']).first()
            user_session.is_active = 0
            user_session.updated_ts = datetime.datetime.utcnow()

            db.session.add(user_session)
            db.session.commit()

            session['session_id'] = None

            return True
        else:
            return False

    except Exception as Error:
        print(str(Error))


def check_if_admin(user_id):
    try:
        user = UserMaster.query.filter_by(id=user_id, is_active=1).first()
        if user:
            if user.is_admin == 1:
                return True
        else:
            return False, None

    except Exception as Error:
        raise Error


def add_question(**kwargs):
    try:
        question = QuestionMaster(
            uuid.uuid4(),
            kwargs['question'],
            kwargs['choice1'],
            kwargs['choice2'],
            kwargs['choice3'],
            kwargs['choice4'],
            kwargs['answer'],
            kwargs['marks'],
            kwargs['remarks']
        )
        db.session.add(question)
        db.session.commit()

    except Exception as Error:
        raise Error


def check_if_session_is_active(session_id):
    try:
        user_session = UserSession.query.filter_by(session_id=session_id, is_active=1).first()
        if user_session:
            return True, user_session.user_id
        else:
            return False, None

    except Exception as Error:
        raise Error


def list_all_questions():
    try:
        questions = QuestionMaster.query.all()
        question_list = list()
        for question in questions:
            question_dict = {}
            question_dict['question'] = question.question
            question_dict['choice1'] = question.choice1
            question_dict['choice2'] = question.choice2
            question_dict['choice3'] = question.choice3
            question_dict['choice4'] = question.choice4
            question_dict['answer'] = question.answer

            question_list.append(question_dict)
        return question_list
    except Exception as error:
        return error


def create_quiz(**kwargs):
    try:
        quiz = QuizMaster(
            uuid.uuid4(),
            kwargs['quiz_name']
        )

        db.session.add(quiz)
        db.session.commit()

    except Exception as Error:
        raise Error


def assign_quiz(**kwargs):
    try:
        assignquiz = QuizInstance(
            uuid.uuid4(),
            kwargs['user_id'],
            kwargs['is_submitted']
        )

        db.session.add(assignquiz)
        db.session.commit()

    except Exception as Error:
        raise Error


def view_quiz(**kwargs):
    try:
        viewquiz = QuizInstance.query.filter_by(quiz_id=kwargs['quiz_id'])
        viewquizlist = list()
        for quiz in viewquiz:
            quiz_dict = {}
            quiz_dict['quiz_name'] = quiz.quiz_name
            quiz_dict['quiz_id'] = quiz.quiz_id
            quiz_dict['score_achieved'] = quiz.score_achieved
            quiz_dict['user_id'] = quiz.user_id

            viewquizlist.append(quiz_dict)
        return viewquizlist

    except Exception as Error:
        raise Error


def check_quiz_access(**kwargs):
    try:
        quizAccess = QuizMaster.query.filter_by(quiz_id=kwargs['quiz_id'], user_id=kwargs['user_id']).first()
        if quizAccess:
            print('user has access')
            return True
        else:
            return False

    except Exception as Error:
        raise Error


def view_assigned_quiz(**kwargs):
    try:
        quiz_info = QuizInstance.query.filter_by(**kwargs).all()
        quiz_info_list = list()
        for assignedquiz in quiz_info:
            assignedquiz_dict = {}
            assignedquiz_dict['quiz_id'] = assignedquiz.quiz_id
            assignedquiz_dict['quiz_name'] = assignedquiz.quiz_name
            assignedquiz_dict['user_id'] = assignedquiz.user_id

            quiz_info_list.append(assignedquiz_dict)
        return quiz_info_list

    except Exception as Error:
        raise Error


def view_all_quiz():
    try:
        quiz_info = QuizMaster.query.all()
        viewallquizList = list()
        for quizzes in quiz_info:
            quizzes_dict = {}
            quizzes_dict['quiz_name'] = quizzes.quiz_name
            quizzes_dict['quiz_id'] = quizzes.quiz_id
            viewallquizList.append(quizzes_dict)

            if not viewallquizList:
                return 'No quizzes found.'
        else:
            return viewallquizList
    except Exception as Error:
        raise Error


'''viewquiz = QuizMaster.query.all()
        if viewquiz:
            return True
        else:
            return False

    except Exception as Error:
        raise Error'''


def attempt_quiz(**kwargs):
    try:
        attemp_list = list()
        attemptquiz = UserResponses.query.filter_by(quiz_id=kwargs['quiz_id'], user_id=kwargs['user_id']).first()
        if attemptquiz:
            attemp_list.append(attemptquiz)
            return attemp_list
        else:
            new_attempt = UserResponses(quiz_id=kwargs['quiz_id'], user_id=kwargs['user_id'])
            db.session.add(new_attempt)
            db.session.commit()

        return [new_attempt]

    except Exception as Error:
        raise Error


def quiz_results(**kwargs):
    try:
        quiz = QuizMaster.query.filter_by(quiz_id=kwargs['quiz_id'], user_id=kwargs['user_id']).first()
        marks = List
        if quiz:
            quiz.score_achieved += kwargs['marks_obtained']
            db.session.add(quiz)
            db.session.commit()
            marks.append(quiz)
            return True, marks

        else:
            return False, None

    except Exception as Error:
        raise Error

    #     return True
    #     else:
    #         return False, None
    #     db.session.add(quiz)
    #     db.session.commit()
    #     return True, user_session.session_id

    #     db.session.add(quiz)
    #     db.session.commit()

    # except Exception as Error:
    #     raise Error
